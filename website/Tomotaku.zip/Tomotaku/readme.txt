1. Install Nodejs

2. Extract Tomotaku to your directory

3. Open cmd.exe and go to tomotaku directory by using "cd" command

4. Install packages by typing "npm install"

5. Install python 2.7 and add it to your global variables

6. Create a google server API key and simsimi API key.

7. Go into Tomotaku repository and edit the file “server.js” by entering your API keys

8. Start the bot by typing "node server.js your_bot_email your_bot_password"
